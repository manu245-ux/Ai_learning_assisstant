<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireAdmin();
$db = Database::getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $action = $_POST['action'] ?? '';
    $targetId = (int) ($_POST['user_id'] ?? 0);

    if ($targetId === (int) $_SESSION['user_id']) {
        setFlash('error', 'You cannot modify your own account from here.');
    } elseif ($action === 'toggle_active') {
        $db->prepare('UPDATE users SET is_active = 1 - is_active WHERE id = ?')->execute([$targetId]);
        logActivity($_SESSION['user_id'], 'admin_toggle_user', "Toggled active status for user #$targetId");
    } elseif ($action === 'make_admin') {
        $db->prepare('UPDATE users SET role = "admin" WHERE id = ?')->execute([$targetId]);
        logActivity($_SESSION['user_id'], 'admin_promote', "Promoted user #$targetId to admin");
    } elseif ($action === 'make_student') {
        $db->prepare('UPDATE users SET role = "student" WHERE id = ?')->execute([$targetId]);
        logActivity($_SESSION['user_id'], 'admin_demote', "Demoted user #$targetId to student");
    } elseif ($action === 'delete_user') {
        $db->prepare('DELETE FROM users WHERE id = ?')->execute([$targetId]);
        logActivity($_SESSION['user_id'], 'admin_delete_user', "Deleted user #$targetId");
    }
    redirect(APP_URL . '/admin/users.php');
}

$users = $db->query('SELECT id, full_name, email, role, is_active, created_at FROM users ORDER BY created_at DESC')->fetchAll();
$pageTitle = 'User Management';
include __DIR__ . '/../includes/header.php';
?>
<div class="admin-tabs mb-3">
  <a href="index.php" class="mode-pill">Overview</a>
  <a href="users.php" class="mode-pill active">User Management</a>
  <a href="logs.php" class="mode-pill">Activity Logs</a>
</div>

<div class="card-panel">
  <h3>All Users (<?= count($users) ?>)</h3>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= e($u['full_name']) ?></td>
          <td><?= e($u['email']) ?></td>
          <td><span class="badge bg-<?= $u['role']==='admin'?'danger':'primary' ?>"><?= e($u['role']) ?></span></td>
          <td><span class="badge bg-<?= $u['is_active']?'success':'secondary' ?>"><?= $u['is_active']?'Active':'Disabled' ?></span></td>
          <td><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
          <td>
            <?php if ((int)$u['id'] !== (int)$_SESSION['user_id']): ?>
            <form method="POST" class="d-inline">
              <?= csrfField() ?>
              <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
              <button class="btn btn-sm btn-outline-secondary" name="action" value="toggle_active"><?= $u['is_active']?'Disable':'Enable' ?></button>
              <?php if ($u['role'] === 'admin'): ?>
                <button class="btn btn-sm btn-outline-secondary" name="action" value="make_student">Demote</button>
              <?php else: ?>
                <button class="btn btn-sm btn-outline-secondary" name="action" value="make_admin">Promote</button>
              <?php endif; ?>
              <button class="btn btn-sm btn-outline-danger" name="action" value="delete_user" onclick="return confirm('Delete this user permanently?')">Delete</button>
            </form>
            <?php else: ?>
              <span class="text-muted small">(you)</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
