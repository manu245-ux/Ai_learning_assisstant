<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireAdmin();
$db = Database::getConnection();

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 40;
$offset = ($page - 1) * $perPage;

$total = $db->query('SELECT COUNT(*) c FROM activity_logs')->fetch()['c'];
$stmt = $db->prepare(
    'SELECT al.*, u.full_name FROM activity_logs al LEFT JOIN users u ON u.id = al.user_id
     ORDER BY al.created_at DESC LIMIT ? OFFSET ?'
);
$stmt->bindValue(1, $perPage, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$logs = $stmt->fetchAll();
$totalPages = (int) ceil($total / $perPage);

$pageTitle = 'Activity Logs';
include __DIR__ . '/../includes/header.php';
?>
<div class="admin-tabs mb-3">
  <a href="index.php" class="mode-pill">Overview</a>
  <a href="users.php" class="mode-pill">User Management</a>
  <a href="logs.php" class="mode-pill active">Activity Logs</a>
</div>

<div class="card-panel">
  <h3>Activity Logs (<?= (int)$total ?> total)</h3>
  <div class="table-responsive">
    <table class="table table-sm">
      <thead><tr><th>#</th><th>User</th><th>Action</th><th>Description</th><th>IP</th><th>Time</th></tr></thead>
      <tbody>
      <?php foreach ($logs as $log): ?>
        <tr>
          <td><?= (int)$log['id'] ?></td>
          <td><?= e($log['full_name'] ?? 'Guest') ?></td>
          <td><span class="badge bg-secondary"><?= e($log['action']) ?></span></td>
          <td><?= e($log['description']) ?></td>
          <td><?= e($log['ip_address']) ?></td>
          <td><?= e(date('M j, Y g:ia', strtotime($log['created_at']))) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($totalPages > 1): ?>
  <nav><ul class="pagination">
    <?php for ($p = 1; $p <= $totalPages; $p++): ?>
      <li class="page-item <?= $p===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a></li>
    <?php endfor; ?>
  </ul></nav>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
