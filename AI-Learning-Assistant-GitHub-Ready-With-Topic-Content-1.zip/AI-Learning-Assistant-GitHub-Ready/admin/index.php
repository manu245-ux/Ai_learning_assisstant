<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireAdmin();
$db = Database::getConnection();

$totals = [];
$totals['users'] = $db->query('SELECT COUNT(*) c FROM users')->fetch()['c'];
$totals['chats'] = $db->query('SELECT COUNT(*) c FROM chat_sessions')->fetch()['c'];
$totals['messages'] = $db->query('SELECT COUNT(*) c FROM messages')->fetch()['c'];
$totals['uploads'] = $db->query('SELECT COUNT(*) c FROM uploads')->fetch()['c'];

$recentLogs = $db->query(
    'SELECT al.*, u.full_name FROM activity_logs al LEFT JOIN users u ON u.id = al.user_id ORDER BY al.created_at DESC LIMIT 15'
)->fetchAll();

$pageTitle = 'Admin Panel';
include __DIR__ . '/../includes/header.php';
?>
<div class="admin-tabs mb-3">
  <a href="index.php" class="mode-pill active">Overview</a>
  <a href="users.php" class="mode-pill">User Management</a>
  <a href="logs.php" class="mode-pill">Activity Logs</a>
</div>

<div class="stat-grid">
  <div class="stat-card"><i class="fa-solid fa-users"></i><div><span class="stat-number"><?= (int)$totals['users'] ?></span><span class="stat-label">Total Users</span></div></div>
  <div class="stat-card"><i class="fa-solid fa-comments"></i><div><span class="stat-number"><?= (int)$totals['chats'] ?></span><span class="stat-label">Chat Sessions</span></div></div>
  <div class="stat-card"><i class="fa-solid fa-message"></i><div><span class="stat-number"><?= (int)$totals['messages'] ?></span><span class="stat-label">Messages</span></div></div>
  <div class="stat-card"><i class="fa-solid fa-file-pdf"></i><div><span class="stat-number"><?= (int)$totals['uploads'] ?></span><span class="stat-label">PDF Uploads</span></div></div>
</div>

<div class="card-panel">
  <h3>Recent Activity</h3>
  <div class="table-responsive">
    <table class="table table-sm">
      <thead><tr><th>User</th><th>Action</th><th>Description</th><th>IP</th><th>Time</th></tr></thead>
      <tbody>
      <?php foreach ($recentLogs as $log): ?>
        <tr>
          <td><?= e($log['full_name'] ?? 'Guest') ?></td>
          <td><span class="badge bg-secondary"><?= e($log['action']) ?></span></td>
          <td><?= e($log['description']) ?></td>
          <td><?= e($log['ip_address']) ?></td>
          <td><?= e(date('M j, g:ia', strtotime($log['created_at']))) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
