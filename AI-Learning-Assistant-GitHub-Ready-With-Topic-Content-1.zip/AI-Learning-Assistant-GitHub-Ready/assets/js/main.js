/**
 * assets/js/main.js
 * Shared behavior across all pages: dark mode toggle, mobile sidebar toggle.
 */
document.addEventListener('DOMContentLoaded', function () {
  // ---- Dark mode toggle ----
  const themeToggle = document.getElementById('themeToggle');
  const html = document.documentElement;

  function applyThemeIcon() {
    if (!themeToggle) return;
    const icon = themeToggle.querySelector('i');
    if (!icon) return;
    icon.className = html.getAttribute('data-theme') === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  }
  applyThemeIcon();

  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      const current = html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      const next = current === 'dark' ? 'light' : 'dark';
      html.setAttribute('data-theme', next);
      applyThemeIcon();

      // Persist to server silently
      const csrfInput = document.querySelector('input[name="csrf_token"]');
      const csrf = csrfInput ? csrfInput.value : (window.__csrf || '');
      fetch((window.APP_URL || '.') + '/settings.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'theme=' + encodeURIComponent(next) + '&csrf_token=' + encodeURIComponent(csrf),
      }).catch(() => {});
    });
  }

  // ---- Mobile sidebar toggle ----
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('appSidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  // ---- Chat list search toggle (mobile) ----
  const chatListPanel = document.querySelector('.chat-list-panel');
  const chatSidebarToggle = document.getElementById('sidebarToggle');
  if (chatListPanel && chatSidebarToggle) {
    chatSidebarToggle.addEventListener('click', () => chatListPanel.classList.toggle('open'));
  }
});
