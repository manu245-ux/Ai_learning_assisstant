/**
 * assets/js/chat.js
 * Powers the ChatGPT-like chat.php interface.
 */
(function () {
  const layout = document.querySelector('.chat-layout');
  if (!layout) return;

  const csrfToken = layout.dataset.csrf;
  let activeChatId = parseInt(layout.dataset.activeChat, 10);
  let currentMode = layout.dataset.mode || 'chat';

  const messagesEl = document.getElementById('chatMessages');
  const emptyState = document.getElementById('chatEmptyState');
  const inputEl = document.getElementById('chatInput');
  const sendBtn = document.getElementById('sendBtn');
  const stopBtn = document.getElementById('stopBtn');
  const newChatBtn = document.getElementById('newChatBtn');
  const searchInput = document.getElementById('chatSearchInput');

  let abortController = null;
  let lastUserMessage = null;

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.innerText = str;
    return div.innerHTML;
  }

  function renderMarkdown(text) {
    const html = marked.parse(text || '');
    return html;
  }

  function highlightAll(container) {
    container.querySelectorAll('pre code').forEach((block) => hljs.highlightElement(block));
  }

  function addMessageBubble(role, text, opts = {}) {
    if (emptyState) emptyState.style.display = 'none';
    const wrap = document.createElement('div');
    wrap.className = 'msg msg-' + role;
    const bubbleId = 'bubble-' + Date.now() + '-' + Math.floor(Math.random() * 1000);

    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    bubble.id = bubbleId;

    if (role === 'user') {
      bubble.innerText = text;
    } else if (opts.loading) {
      bubble.innerHTML = '<span class="typing-dots"><span></span><span></span><span></span></span>';
    } else {
      bubble.innerHTML = renderMarkdown(text);
    }

    wrap.appendChild(bubble);

    if (role === 'assistant' && !opts.loading) {
      const actions = document.createElement('div');
      actions.className = 'msg-actions';
      actions.innerHTML = '<button class="copy-btn"><i class="fa-regular fa-copy"></i> Copy</button>';
      actions.querySelector('.copy-btn').addEventListener('click', () => {
        navigator.clipboard.writeText(text);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Copied!', showConfirmButton: false, timer: 1200 });
      });
      wrap.appendChild(actions);
    }

    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return bubbleId;
  }

  async function loadMessages(chatId) {
    messagesEl.innerHTML = '';
    try {
      const res = await fetch(`chat/get_messages.php?chat_session_id=${chatId}`);
      const data = await res.json();
      if (data.success && data.messages.length) {
        data.messages.forEach((m) => addMessageBubble(m.role, m.content));
      } else {
        messagesEl.innerHTML = '<div class="chat-empty-state"><i class="fa-solid fa-robot fa-2x"></i><p>Ask a question, paste your notes, or pick a study tool from the sidebar.</p></div>';
      }
    } catch (e) {
      messagesEl.innerHTML = '<div class="chat-empty-state text-danger">Failed to load messages.</div>';
    }
  }

  async function sendMessage(text) {
    if (!text.trim()) return;
    lastUserMessage = text;
    addMessageBubble('user', text);
    inputEl.value = '';
    inputEl.style.height = 'auto';

    const loadingId = addMessageBubble('assistant', '', { loading: true });
    sendBtn.classList.add('d-none');
    stopBtn.classList.remove('d-none');
    abortController = new AbortController();

    try {
      const body = new URLSearchParams({
        chat_session_id: activeChatId,
        message: text,
        mode: currentMode,
        csrf_token: csrfToken,
      });
      const res = await fetch('api/send_message.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: abortController.signal,
      });
      const data = await res.json();
      const bubble = document.getElementById(loadingId);
      if (data.success) {
        bubble.innerHTML = renderMarkdown(data.reply);
        highlightAll(bubble.parentElement);
        const actions = document.createElement('div');
        actions.className = 'msg-actions';
        actions.innerHTML = '<button class="copy-btn"><i class="fa-regular fa-copy"></i> Copy</button> <button class="regen-btn"><i class="fa-solid fa-rotate-right"></i> Regenerate</button>';
        actions.querySelector('.copy-btn').addEventListener('click', () => {
          navigator.clipboard.writeText(data.reply);
          Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Copied!', showConfirmButton: false, timer: 1200 });
        });
        actions.querySelector('.regen-btn').addEventListener('click', () => sendMessage(lastUserMessage));
        bubble.parentElement.appendChild(actions);
      } else {
        bubble.innerHTML = `<span class="text-danger">${escapeHtml(data.error || 'Something went wrong.')}</span>`;
      }
    } catch (err) {
      const bubble = document.getElementById(loadingId);
      if (bubble) {
        bubble.innerHTML = err.name === 'AbortError'
          ? '<span class="text-muted">Response stopped.</span>'
          : '<span class="text-danger">Request failed. Please try again.</span>';
      }
    } finally {
      sendBtn.classList.remove('d-none');
      stopBtn.classList.add('d-none');
      abortController = null;
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }
  }

  // ---- Event wiring ----
  sendBtn.addEventListener('click', () => sendMessage(inputEl.value));
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(inputEl.value);
    }
  });
  inputEl.addEventListener('input', () => {
    inputEl.style.height = 'auto';
    inputEl.style.height = Math.min(inputEl.scrollHeight, 160) + 'px';
  });

  stopBtn.addEventListener('click', () => {
    if (abortController) abortController.abort();
  });

  newChatBtn.addEventListener('click', async () => {
    const res = await fetch('chat/new_chat.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'csrf_token=' + encodeURIComponent(csrfToken),
    });
    const data = await res.json();
    if (data.success) window.location = 'chat.php?id=' + data.chat_session_id;
  });

  document.querySelectorAll('.chat-list-item').forEach((item) => {
    const id = item.dataset.id;

    const renameBtn = item.querySelector('.rename-btn');
    if (renameBtn) {
      renameBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        const { value: title } = await Swal.fire({
          title: 'Rename conversation',
          input: 'text',
          inputValue: item.querySelector('.chat-title-text').innerText,
          showCancelButton: true,
        });
        if (title) {
          const res = await fetch('chat/rename.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `chat_session_id=${id}&title=${encodeURIComponent(title)}&csrf_token=${encodeURIComponent(csrfToken)}`,
          });
          const data = await res.json();
          if (data.success) item.querySelector('.chat-title-text').innerText = title;
        }
      });
    }

    const deleteBtn = item.querySelector('.delete-btn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        const confirmed = await Swal.fire({ title: 'Delete this chat?', text: 'This cannot be undone.', icon: 'warning', showCancelButton: true, confirmButtonText: 'Delete' });
        if (confirmed.isConfirmed) {
          const res = await fetch('chat/delete.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `chat_session_id=${id}&csrf_token=${encodeURIComponent(csrfToken)}`,
          });
          const data = await res.json();
          if (data.success) {
            if (parseInt(id, 10) === activeChatId) {
              window.location = 'chat.php';
            } else {
              item.remove();
            }
          }
        }
      });
    }
  });

  // ---- Search ----
  let searchTimeout = null;
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      clearTimeout(searchTimeout);
      const q = searchInput.value.trim();
      searchTimeout = setTimeout(async () => {
        if (q.length < 2) return;
        const res = await fetch('chat/search.php?q=' + encodeURIComponent(q));
        const data = await res.json();
        const modalBody = document.getElementById('searchResultsBody');
        if (data.results && data.results.length) {
          modalBody.innerHTML = data.results.map(r =>
            `<a href="chat.php?id=${r.id}" class="d-block py-2 border-bottom">${escapeHtml(r.title)}</a>`
          ).join('');
        } else {
          modalBody.innerHTML = '<p class="text-muted">No matching conversations found.</p>';
        }
        const modal = new bootstrap.Modal(document.getElementById('searchModal'));
        modal.show();
      }, 400);
    });
  }

  // Initial load
  loadMessages(activeChatId);
})();
