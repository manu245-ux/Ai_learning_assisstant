<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (isLoggedIn()) {
    logActivity($_SESSION['user_id'], 'logout', 'User logged out');
}
$_SESSION = [];
session_destroy();
redirect(APP_URL . '/login.php');
