<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (isLoggedIn()) redirect(APP_URL . '/dashboard.php');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();

    $fullName = trim($_POST['full_name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if ($fullName === '' || strlen($fullName) < 2) $errors[] = 'Please enter your full name.';
    if (!isValidEmail($email)) $errors[] = 'Please enter a valid email address.';
    if (!isStrongPassword($password)) $errors[] = 'Password must be at least 8 characters and include a letter and a number.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $db = Database::getConnection();
        $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with that email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare('INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)');
            $stmt->execute([$fullName, $email, $hash]);
            $userId = (int) $db->lastInsertId();

            // Create a default first chat
            $db->prepare('INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)')
               ->execute([$userId, 'Welcome Chat']);

            logActivity($userId, 'register', 'New account created');
            setFlash('success', 'Account created successfully! Please log in.');
            redirect(APP_URL . '/login.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-body">
  <div class="auth-card">
    <div class="auth-brand"><i class="fa-solid fa-graduation-cap"></i> <?= e(APP_NAME) ?></div>
    <h2>Create your account</h2>
    <p class="text-muted">Start learning smarter with AI.</p>

    <?php if ($errors): ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <?= csrfField() ?>
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="full_name" class="form-control" required value="<?= e($_POST['full_name'] ?? '') ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required minlength="8">
        <div class="form-text">At least 8 characters, with a letter and a number.</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input type="password" name="confirm_password" class="form-control" required minlength="8">
      </div>
      <button type="submit" class="btn btn-primary w-100">Create Account</button>
    </form>
    <p class="text-center mt-3">Already have an account? <a href="login.php">Log in</a></p>
  </div>
</body>
</html>
