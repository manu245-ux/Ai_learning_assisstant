<?php
/** includes/header.php - shared <head> and topbar. Expects $pageTitle to be set. */
$user = currentUser();
$theme = $user['theme'] ?? 'light';
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= e($theme) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? APP_NAME) ?> · <?= e(APP_NAME) ?></title>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<!-- highlight.js theme -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css">
<!-- App CSS -->
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <?php include __DIR__ . '/sidebar.php'; ?>
  <div class="app-main">
    <header class="topbar">
      <button class="btn-icon d-lg-none" id="sidebarToggle"><i class="fa-solid fa-bars"></i></button>
      <h1 class="topbar-title"><?= e($pageTitle ?? '') ?></h1>
      <div class="topbar-actions">
        <button class="btn-icon" id="themeToggle" title="Toggle dark mode">
          <i class="fa-solid fa-moon"></i>
        </button>
        <div class="dropdown">
          <button class="btn-icon dropdown-toggle" data-bs-toggle="dropdown">
            <i class="fa-solid fa-user-circle"></i>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="<?= APP_URL ?>/profile.php"><i class="fa-solid fa-id-card me-2"></i>Profile</a></li>
            <li><a class="dropdown-item" href="<?= APP_URL ?>/settings.php"><i class="fa-solid fa-gear me-2"></i>Settings</a></li>
            <?php if (($user['role'] ?? '') === 'admin'): ?>
            <li><a class="dropdown-item" href="<?= APP_URL ?>/admin/index.php"><i class="fa-solid fa-shield-halved me-2"></i>Admin Panel</a></li>
            <?php endif; ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?= APP_URL ?>/logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
          </ul>
        </div>
      </div>
    </header>
    <main class="app-content">
