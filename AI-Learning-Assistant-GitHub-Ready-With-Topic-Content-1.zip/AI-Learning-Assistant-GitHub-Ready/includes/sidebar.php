<?php
/** includes/sidebar.php */
$current = basename($_SERVER['PHP_SELF']);
function navActive(string $file, string $current): string {
    return $file === $current ? 'active' : '';
}
?>
<aside class="sidebar" id="appSidebar">
  <div class="sidebar-brand">
    <i class="fa-solid fa-graduation-cap"></i>
    <span>AI Learning Assistant</span>
  </div>

  <a href="<?= APP_URL ?>/dashboard.php" class="nav-link <?= navActive('dashboard.php', $current) ?>">
    <i class="fa-solid fa-gauge-high"></i><span>Dashboard</span>
  </a>
  <a href="<?= APP_URL ?>/chat.php" class="nav-link <?= navActive('chat.php', $current) ?>">
    <i class="fa-solid fa-comments"></i><span>AI Chat</span>
  </a>

  <div class="nav-section-label">Study Tools</div>
  <a href="<?= APP_URL ?>/notes/index.php" class="nav-link"><i class="fa-solid fa-file-lines"></i><span>Notes Summarizer</span></a>
  <a href="<?= APP_URL ?>/quiz/index.php" class="nav-link"><i class="fa-solid fa-circle-question"></i><span>Quiz Generator</span></a>
  <a href="<?= APP_URL ?>/flashcards/index.php" class="nav-link"><i class="fa-solid fa-clone"></i><span>Flashcards</span></a>
  <a href="<?= APP_URL ?>/pdf/index.php" class="nav-link"><i class="fa-solid fa-file-pdf"></i><span>PDF Q&amp;A</span></a>
  <a href="<?= APP_URL ?>/chat.php?mode=code" class="nav-link"><i class="fa-solid fa-code"></i><span>Code Generator</span></a>
  <a href="<?= APP_URL ?>/chat.php?mode=math" class="nav-link"><i class="fa-solid fa-square-root-variable"></i><span>Math Solver</span></a>
  <a href="<?= APP_URL ?>/chat.php?mode=assignment" class="nav-link"><i class="fa-solid fa-pen-to-square"></i><span>Assignment Helper</span></a>

  <div class="nav-section-label">Account</div>
  <a href="<?= APP_URL ?>/profile.php" class="nav-link <?= navActive('profile.php', $current) ?>"><i class="fa-solid fa-id-card"></i><span>Profile</span></a>
  <a href="<?= APP_URL ?>/settings.php" class="nav-link <?= navActive('settings.php', $current) ?>"><i class="fa-solid fa-gear"></i><span>Settings</span></a>

  <div class="sidebar-footer">
    <a href="<?= APP_URL ?>/logout.php" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a>
  </div>
</aside>
