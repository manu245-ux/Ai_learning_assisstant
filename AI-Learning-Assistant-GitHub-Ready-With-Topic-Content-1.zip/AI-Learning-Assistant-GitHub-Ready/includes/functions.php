<?php
/**
 * includes/functions.php
 * Shared helper functions: sanitization, redirects, logging, flash messages.
 */
require_once __DIR__ . '/../config/database.php';

/** Escape output to prevent XSS */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Redirect helper */
function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

/** Is the current user logged in? */
function isLoggedIn(): bool
{
    return !empty($_SESSION['user_id']);
}

/** Force login, otherwise redirect */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        redirect(APP_URL . '/login.php');
    }
}

/** Force admin role */
function requireAdmin(): void
{
    requireLogin();
    if (($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403);
        die('Access denied. Admins only.');
    }
}

/** Get currently logged in user's row */
function currentUser(): ?array
{
    if (!isLoggedIn()) return null;
    static $cache = null;
    if ($cache !== null) return $cache;
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT id, full_name, email, role, avatar, theme FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $cache = $stmt->fetch() ?: null;
    return $cache;
}

/** Log an activity for the admin panel */
function logActivity(?int $userId, string $action, string $description = ''): void
{
    try {
        $db = Database::getConnection();
        $stmt = $db->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $stmt->execute([$userId, $action, $description, $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Exception $e) {
        error_log('Activity log failed: ' . $e->getMessage());
    }
}

/** Flash messages (one-time session messages) */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'][$type] = $message;
}

function getFlash(string $type): ?string
{
    if (!empty($_SESSION['flash'][$type])) {
        $msg = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $msg;
    }
    return null;
}

/** Basic JSON response helper for AJAX endpoints */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/** Validate email format */
function isValidEmail(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

/** Password strength check: min 8 chars, at least 1 letter and 1 number */
function isStrongPassword(string $password): bool
{
    return strlen($password) >= 8 && preg_match('/[A-Za-z]/', $password) && preg_match('/[0-9]/', $password);
}
