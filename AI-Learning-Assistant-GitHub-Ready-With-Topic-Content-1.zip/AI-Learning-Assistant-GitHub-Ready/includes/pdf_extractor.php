<?php
/**
 * includes/pdf_extractor.php
 * A minimal, dependency-free PDF text extractor.
 *
 * LIMITATIONS (documented honestly, see README):
 * - Works well for standard text-based PDFs (Word/Google Docs exports, most lecture slides/notes).
 * - Does NOT perform OCR, so scanned/image-only PDFs will return little or no text.
 * - Complex layouts (multi-column, heavy custom fonts/ligatures) may extract with minor artifacts.
 * For production-grade extraction, consider installing the `smalot/pdfparser` Composer package
 * and swapping the implementation inside extractTextFromPdf().
 */

function extractTextFromPdf(string $filePath): string
{
    $raw = file_get_contents($filePath);
    if ($raw === false) return '';

    // 1. Find all stream...endstream blocks
    $text = '';
    if (preg_match_all('/stream\r?\n(.*?)\r?\nendstream/s', $raw, $matches)) {
        foreach ($matches[1] as $stream) {
            $decoded = @gzuncompress($stream);
            if ($decoded === false) {
                // Not FlateDecode (or already plain) — try raw
                $decoded = $stream;
            }
            $text .= extractTjOperators($decoded);
        }
    }

    // Clean up whitespace
    $text = preg_replace('/[ \t]+/', ' ', $text);
    $text = preg_replace('/\n{3,}/', "\n\n", $text);
    return trim($text);
}

/**
 * Extract literal text from PDF content-stream Tj / TJ operators.
 */
function extractTjOperators(string $content): string
{
    $out = '';

    // (text) Tj
    if (preg_match_all('/\((?:[^()\\\\]|\\\\.)*\)\s*Tj/', $content, $m)) {
        foreach ($m[0] as $chunk) {
            $out .= decodePdfLiteral($chunk) . ' ';
        }
    }

    // [ (text) (text) ... ] TJ
    if (preg_match_all('/\[((?:[^\[\]]|\\\\.)*)\]\s*TJ/', $content, $m)) {
        foreach ($m[1] as $arrayBody) {
            if (preg_match_all('/\((?:[^()\\\\]|\\\\.)*\)/', $arrayBody, $lits)) {
                foreach ($lits[0] as $lit) {
                    $out .= decodePdfLiteral($lit) . '';
                }
                $out .= ' ';
            }
        }
    }

    // Heuristic line breaks on common text-positioning operators
    $out = str_replace(['Td', 'TD', 'T*'], "\n", $out);

    return $out . "\n";
}

function decodePdfLiteral(string $literalWithOp): string
{
    // Strip the trailing operator (Tj) and surrounding parentheses
    $str = preg_replace('/\s*T[jJ]?$/', '', $literalWithOp);
    $str = trim($str);
    if (strlen($str) >= 2 && $str[0] === '(' && substr($str, -1) === ')') {
        $str = substr($str, 1, -1);
    }
    // Unescape PDF string escapes
    $str = str_replace(['\\(', '\\)', '\\\\'], ['(', ')', '\\'], $str);
    $str = preg_replace_callback('/\\\\([0-7]{1,3})/', fn($m) => chr(octdec($m[1])), $str);
    return $str;
}
