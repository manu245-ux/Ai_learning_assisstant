<?php
/**
 * includes/bootstrap.php
 * Include this at the top of every page. Loads config, DB, helpers, CSRF.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';
