<?php
require_once __DIR__ . '/includes/bootstrap.php';
requireLogin();

$db = Database::getConnection();
$userId = (int) $_SESSION['user_id'];
$mode = $_GET['mode'] ?? 'chat'; // chat, code, math, assignment

// Determine active chat session (create one if none exists)
$activeId = (int) ($_GET['id'] ?? 0);
$stmt = $db->prepare('SELECT id FROM chat_sessions WHERE user_id = ? AND id = ?');
$stmt->execute([$userId, $activeId]);
if (!$stmt->fetch()) {
    $stmt = $db->prepare('SELECT id FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row) {
        $activeId = (int) $row['id'];
    } else {
        $db->prepare('INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)')->execute([$userId, 'New Chat']);
        $activeId = (int) $db->lastInsertId();
    }
}

$stmt = $db->prepare('SELECT id, title, updated_at FROM chat_sessions WHERE user_id = ? ORDER BY is_pinned DESC, updated_at DESC');
$stmt->execute([$userId]);
$allChats = $stmt->fetchAll();

$pageTitle = 'AI Chat';
include __DIR__ . '/includes/header.php';
?>

<div class="chat-layout" data-active-chat="<?= (int)$activeId ?>" data-mode="<?= e($mode) ?>" data-csrf="<?= e(csrfToken()) ?>">

  <!-- Conversation list -->
  <div class="chat-list-panel">
    <div class="chat-list-header">
      <button class="btn btn-primary btn-sm w-100" id="newChatBtn"><i class="fa-solid fa-plus"></i> New Chat</button>
    </div>
    <div class="chat-search-box">
      <input type="text" id="chatSearchInput" class="form-control form-control-sm" placeholder="Search chat history...">
    </div>
    <div class="chat-list" id="chatList">
      <?php foreach ($allChats as $c): ?>
        <div class="chat-list-item <?= $c['id'] == $activeId ? 'active' : '' ?>" data-id="<?= (int)$c['id'] ?>">
          <a href="?id=<?= (int)$c['id'] ?>" class="chat-list-link"><i class="fa-regular fa-message"></i> <span class="chat-title-text"><?= e($c['title']) ?></span></a>
          <div class="chat-item-actions">
            <button class="btn-icon-sm rename-btn" title="Rename"><i class="fa-solid fa-pen"></i></button>
            <button class="btn-icon-sm delete-btn" title="Delete"><i class="fa-solid fa-trash"></i></button>
            <div class="dropdown d-inline-block">
              <button class="btn-icon-sm" data-bs-toggle="dropdown" title="Export"><i class="fa-solid fa-download"></i></button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="chat/export.php?chat_session_id=<?= (int)$c['id'] ?>&format=txt">Export as TXT</a></li>
                <li><a class="dropdown-item" href="chat/export.php?chat_session_id=<?= (int)$c['id'] ?>&format=pdf">Export as PDF</a></li>
              </ul>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Message area -->
  <div class="chat-main">
    <div class="chat-mode-bar">
      <a href="?id=<?= $activeId ?>&mode=chat" class="mode-pill <?= $mode==='chat'?'active':'' ?>"><i class="fa-solid fa-comments"></i> Chat</a>
      <a href="?id=<?= $activeId ?>&mode=code" class="mode-pill <?= $mode==='code'?'active':'' ?>"><i class="fa-solid fa-code"></i> Code</a>
      <a href="?id=<?= $activeId ?>&mode=math" class="mode-pill <?= $mode==='math'?'active':'' ?>"><i class="fa-solid fa-square-root-variable"></i> Math</a>
      <a href="?id=<?= $activeId ?>&mode=assignment" class="mode-pill <?= $mode==='assignment'?'active':'' ?>"><i class="fa-solid fa-pen-to-square"></i> Assignment</a>
    </div>

    <div class="chat-messages" id="chatMessages">
      <!-- messages injected by JS -->
      <div class="chat-empty-state" id="chatEmptyState">
        <i class="fa-solid fa-robot fa-2x"></i>
        <p>Ask a question, paste your notes, or pick a study tool from the sidebar.</p>
      </div>
    </div>

    <div class="chat-input-bar">
      <textarea id="chatInput" class="form-control" placeholder="Message AI Learning Assistant..." rows="1"></textarea>
      <button class="btn btn-primary" id="sendBtn"><i class="fa-solid fa-paper-plane"></i></button>
      <button class="btn btn-outline-danger d-none" id="stopBtn"><i class="fa-solid fa-stop"></i></button>
    </div>
    <div class="chat-disclaimer">AI can make mistakes. Verify important information.</div>
  </div>
</div>

<!-- Search results modal -->
<div class="modal fade" id="searchModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Search Results</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" id="searchResultsBody"><p class="text-muted">Type at least 2 characters to search.</p></div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
<script src="<?= APP_URL ?>/assets/js/chat.js"></script>
