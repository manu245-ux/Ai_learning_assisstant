<?php
/**
 * api/gemini.php
 * Thin wrapper around the Google Gemini generateContent REST API.
 */
require_once __DIR__ . '/../config/config.php';

class GeminiException extends Exception {}

class Gemini
{
    /**
     * Send a prompt (optionally with prior turns) to Gemini and return plain text.
     *
     * @param string $prompt          The user's latest message / instruction.
     * @param array  $history         Array of ['role' => 'user'|'model', 'text' => string]
     * @param string|null $systemInstruction Optional system prompt.
     * @return string Assistant's reply text.
     * @throws GeminiException
     */
    public static function generate(string $prompt, array $history = [], ?string $systemInstruction = null): string
    {
        if (GEMINI_API_KEY === '' || GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
            throw new GeminiException('Gemini API key is not configured. Set GEMINI_API_KEY in your environment variables.');
        }

        $contents = [];
        foreach ($history as $turn) {
            $contents[] = [
                'role'  => $turn['role'] === 'assistant' ? 'model' : 'user',
                'parts' => [['text' => $turn['text']]],
            ];
        }
        $contents[] = ['role' => 'user', 'parts' => [['text' => $prompt]]];

        $payload = ['contents' => $contents];
        if ($systemInstruction) {
            $payload['systemInstruction'] = ['parts' => [['text' => $systemInstruction]]];
        }
        $payload['generationConfig'] = [
            'temperature'     => 0.7,
            'maxOutputTokens' => 2048,
        ];

        $url = GEMINI_ENDPOINT . '?key=' . urlencode(GEMINI_API_KEY);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => GEMINI_TIMEOUT_SECONDS,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            throw new GeminiException('Network error contacting Gemini API: ' . $curlErr);
        }

        $data = json_decode($response, true);

        if ($httpCode === 429) {
            throw new GeminiException('Gemini API rate limit reached. Please wait a moment and try again.');
        }
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? ('HTTP ' . $httpCode);
            throw new GeminiException('Gemini API error: ' . $msg);
        }

        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;

        if ($text === null) {
            $finishReason = $data['candidates'][0]['finishReason'] ?? 'unknown';
            throw new GeminiException('Gemini returned an empty response (reason: ' . $finishReason . ').');
        }

        return $text;
    }
}
