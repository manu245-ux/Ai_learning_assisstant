<?php
/**
 * api/send_message.php
 * POST: chat_session_id, message, mode (chat|code|math|assignment)
 * Returns JSON: { success, reply, chat_session_id }
 */
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/gemini.php';
require_once __DIR__ . '/api.php';

header('Content-Type: application/json');

if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success' => false, 'error' => 'Invalid method.'], 405);
requireCsrf();

$userId        = (int) $_SESSION['user_id'];
$chatSessionId = (int) ($_POST['chat_session_id'] ?? 0);
$message       = trim($_POST['message'] ?? '');
$mode          = $_POST['mode'] ?? 'chat';

if ($message === '' || strlen($message) > 8000) {
    jsonResponse(['success' => false, 'error' => 'Message must be between 1 and 8000 characters.'], 422);
}

$db = Database::getConnection();

// Verify chat session belongs to this user
$stmt = $db->prepare('SELECT id, title FROM chat_sessions WHERE id = ? AND user_id = ?');
$stmt->execute([$chatSessionId, $userId]);
$session = $stmt->fetch();
if (!$session) {
    jsonResponse(['success' => false, 'error' => 'Chat session not found.'], 404);
}

// Save user message
$db->prepare('INSERT INTO messages (chat_session_id, role, content, tool) VALUES (?, ?, ?, ?)')
   ->execute([$chatSessionId, 'user', $message, $mode]);

// Auto-title new chats from first message
if ($session['title'] === 'New Chat' || $session['title'] === 'Welcome Chat') {
    $autoTitle = mb_substr($message, 0, 60);
    $db->prepare('UPDATE chat_sessions SET title = ? WHERE id = ?')->execute([$autoTitle, $chatSessionId]);
}

// Pull last 10 messages for short-term memory
$stmt = $db->prepare('SELECT role, content FROM messages WHERE chat_session_id = ? ORDER BY id DESC LIMIT 10');
$stmt->execute([$chatSessionId]);
$recent = array_reverse($stmt->fetchAll());
$history = [];
foreach ($recent as $m) {
    if ($m['content'] === $message) continue; // skip the message we just inserted, it's added separately
    $history[] = ['role' => $m['role'], 'text' => $m['content']];
}

try {
    $systemInstruction = getSystemInstruction($mode);
    $reply = Gemini::generate($message, $history, $systemInstruction);
} catch (GeminiException $e) {
    logActivity($userId, 'gemini_error', $e->getMessage());
    jsonResponse(['success' => false, 'error' => $e->getMessage()], 502);
}

$db->prepare('INSERT INTO messages (chat_session_id, role, content, tool) VALUES (?, ?, ?, ?)')
   ->execute([$chatSessionId, 'assistant', $reply, $mode]);

$db->prepare('UPDATE chat_sessions SET updated_at = NOW() WHERE id = ?')->execute([$chatSessionId]);

jsonResponse(['success' => true, 'reply' => $reply, 'chat_session_id' => $chatSessionId]);
