<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../api/gemini.php';
require_once __DIR__ . '/../api/api.php';
requireLogin();
$db = Database::getConnection();
$userId = (int) $_SESSION['user_id'];

$summary = null;
$error = null;
$inputText = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $inputText = trim($_POST['source_text'] ?? '');
    if (strlen($inputText) < 30) {
        $error = 'Please paste at least a paragraph of text to summarize.';
    } elseif (strlen($inputText) > 20000) {
        $error = 'Text is too long. Please paste under 20,000 characters.';
    } else {
        [$system, $prompt] = getNotesSummarizerPrompt(mb_substr($inputText, 0, 18000));
        try {
            $summary = Gemini::generate($prompt, [], $system);
            $title = mb_substr($inputText, 0, 60);
            $db->prepare('INSERT INTO notes (user_id, title, source_text, summary) VALUES (?, ?, ?, ?)')
               ->execute([$userId, $title, $inputText, $summary]);
            logActivity($userId, 'notes_summary', 'Generated a notes summary');
        } catch (GeminiException $e) {
            $error = $e->getMessage();
        }
    }
}

$stmt = $db->prepare('SELECT id, title, created_at FROM notes WHERE user_id = ? ORDER BY created_at DESC LIMIT 10');
$stmt->execute([$userId]);
$history = $stmt->fetchAll();

$pageTitle = 'Notes Summarizer';
include __DIR__ . '/../includes/header.php';
?>

<div class="card-panel">
  <h3><i class="fa-solid fa-file-lines"></i> Notes Summarizer</h3>
  <p class="text-muted">Paste your lecture notes, textbook excerpt, or article — get a clean, structured summary for revision.</p>

  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <form method="POST">
    <?= csrfField() ?>
    <textarea name="source_text" class="form-control mb-2" rows="8" placeholder="Paste your text here..." required><?= e($inputText) ?></textarea>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-wand-magic-sparkles"></i> Summarize</button>
  </form>
</div>

<?php if ($summary): ?>
<div class="card-panel">
  <h3>Summary</h3>
  <div class="markdown-body" id="summaryOutput" data-raw="<?= e(base64_encode($summary)) ?>"></div>
  <button class="btn btn-sm btn-outline-secondary mt-2" onclick="copySummary()"><i class="fa-solid fa-copy"></i> Copy</button>
</div>
<?php endif; ?>

<div class="card-panel">
  <h3>Recent Summaries</h3>
  <?php if (empty($history)): ?>
    <p class="text-muted">No summaries yet.</p>
  <?php else: ?>
    <ul class="recent-chat-list">
      <?php foreach ($history as $h): ?>
        <li><?= e($h['title']) ?> <span class="text-muted small"><?= e(date('M j', strtotime($h['created_at']))) ?></span></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
<script>
document.addEventListener('DOMContentLoaded', function(){
  const el = document.getElementById('summaryOutput');
  if (el) {
    const raw = decodeURIComponent(escape(atob(el.dataset.raw)));
    el.innerHTML = marked.parse(raw);
    el.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
    window._summaryRaw = raw;
  }
});
function copySummary(){
  navigator.clipboard.writeText(window._summaryRaw || '');
  Swal.fire({ toast:true, position:'top-end', icon:'success', title:'Copied!', showConfirmButton:false, timer:1500 });
}
</script>
