<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireLogin();
$db = Database::getConnection();
$userId = (int) $_SESSION['user_id'];

// ---- AJAX POST: answer a question about the uploaded PDF ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once __DIR__ . '/../api/gemini.php';
    require_once __DIR__ . '/../api/api.php';
    header('Content-Type: application/json');
    requireCsrf();

    $uploadIdPost = (int) ($_POST['upload_id'] ?? 0);
    $question = trim($_POST['question'] ?? '');

    if ($question === '' || strlen($question) > 2000) {
        jsonResponse(['success' => false, 'error' => 'Question must be 1-2000 characters.'], 422);
    }

    $stmt = $db->prepare('SELECT extracted_text FROM uploads WHERE id = ? AND user_id = ?');
    $stmt->execute([$uploadIdPost, $userId]);
    $row = $stmt->fetch();
    if (!$row) jsonResponse(['success' => false, 'error' => 'Document not found.'], 404);

    $pdfText = mb_substr($row['extracted_text'], 0, MAX_PDF_CHARS_FOR_PROMPT);
    if (trim($pdfText) === '') {
        jsonResponse(['success' => false, 'error' => 'No readable text was extracted from this PDF, so questions cannot be answered.'], 422);
    }

    [$system, $prompt] = getPdfQaPrompt($pdfText, $question);

    try {
        $answer = Gemini::generate($prompt, [], $system);
    } catch (GeminiException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 502);
    }

    jsonResponse(['success' => true, 'answer' => $answer]);
}

// ---- Normal GET: render the page ----
$uploadId = (int) ($_GET['upload_id'] ?? 0);

$stmt = $db->prepare('SELECT * FROM uploads WHERE id = ? AND user_id = ?');
$stmt->execute([$uploadId, $userId]);
$upload = $stmt->fetch();
if (!$upload) { redirect(APP_URL . '/pdf/index.php'); }

$pageTitle = 'Ask: ' . $upload['original_name'];
include __DIR__ . '/../includes/header.php';
?>

<div class="card-panel">
  <h3><i class="fa-solid fa-file-pdf text-danger"></i> <?= e($upload['original_name']) ?></h3>
  <p class="text-muted">
    Extracted <?= number_format(strlen($upload['extracted_text'])) ?> characters
    <?php if (strlen($upload['extracted_text']) < 50): ?>
      — <span class="text-danger">very little text was found. This PDF may be a scanned image without OCR support.</span>
    <?php endif; ?>
  </p>

  <div id="pdfChatMessages" class="chat-messages" style="min-height:300px;"></div>

  <form id="pdfAskForm" class="chat-input-bar mt-2">
    <input type="hidden" name="upload_id" value="<?= (int)$uploadId ?>">
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
    <textarea name="question" id="pdfQuestionInput" class="form-control" rows="1" placeholder="Ask something about this document..." required></textarea>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i></button>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
<script>
const pdfMessages = document.getElementById('pdfChatMessages');
document.getElementById('pdfAskForm').addEventListener('submit', async function(e){
  e.preventDefault();
  const form = new FormData(this);
  const question = form.get('question');
  if (!question.trim()) return;

  pdfMessages.insertAdjacentHTML('beforeend', `<div class="msg msg-user"><div class="msg-bubble">${escapeHtml(question)}</div></div>`);
  const loadingId = 'loading-' + Date.now();
  pdfMessages.insertAdjacentHTML('beforeend', `<div class="msg msg-assistant" id="${loadingId}"><div class="msg-bubble"><span class="typing-dots"><span></span><span></span><span></span></span></div></div>`);
  pdfMessages.scrollTop = pdfMessages.scrollHeight;
  document.getElementById('pdfQuestionInput').value = '';

  try {
    const res = await fetch('ask.php', { method: 'POST', body: form });
    const data = await res.json();
    const el = document.getElementById(loadingId);
    if (data.success) {
      el.innerHTML = `<div class="msg-bubble">${marked.parse(data.answer)}</div>`;
      el.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
    } else {
      el.innerHTML = `<div class="msg-bubble text-danger">${escapeHtml(data.error)}</div>`;
    }
  } catch (err) {
    document.getElementById(loadingId).innerHTML = '<div class="msg-bubble text-danger">Request failed. Please try again.</div>';
  }
  pdfMessages.scrollTop = pdfMessages.scrollHeight;
});
function escapeHtml(s){ const d=document.createElement('div'); d.innerText=s; return d.innerHTML; }
</script>
