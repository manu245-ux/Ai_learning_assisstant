<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/pdf_extractor.php';
header('Content-Type: application/json');

if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success' => false, 'error' => 'Invalid method.'], 405);
requireCsrf();

if (empty($_FILES['pdf_file']) || $_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(['success' => false, 'error' => 'No file uploaded or upload error.'], 422);
}

$file = $_FILES['pdf_file'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

if (!in_array($ext, ALLOWED_UPLOAD_EXT, true)) {
    jsonResponse(['success' => false, 'error' => 'Only PDF files are allowed.'], 422);
}
if ($file['size'] > MAX_UPLOAD_MB * 1024 * 1024) {
    jsonResponse(['success' => false, 'error' => 'File exceeds ' . MAX_UPLOAD_MB . 'MB limit.'], 422);
}

// Verify real MIME type (defense in depth, not just extension)
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);
if ($mime !== 'application/pdf') {
    jsonResponse(['success' => false, 'error' => 'File does not appear to be a valid PDF.'], 422);
}

if (!is_dir(UPLOAD_DIR)) {
    if (!@mkdir(UPLOAD_DIR, 0755, true)) {
        jsonResponse(['success' => false, 'error' => 'Server storage is not writable. If deployed on Railway/Render, attach a persistent volume mounted at ' . UPLOAD_DIR . '.'], 500);
    }
}
if (!is_writable(UPLOAD_DIR)) {
    jsonResponse(['success' => false, 'error' => 'Upload directory is not writable on this server. Check folder permissions or persistent volume configuration.'], 500);
}

$storedName = bin2hex(random_bytes(16)) . '.pdf';
$destination = UPLOAD_DIR . $storedName;

if (!move_uploaded_file($file['tmp_name'], $destination)) {
    jsonResponse(['success' => false, 'error' => 'Failed to save the uploaded file.'], 500);
}

$extractedText = extractTextFromPdf($destination);
$pageCountGuess = max(1, substr_count(file_get_contents($destination), '/Type /Page') ?: 1);

$db = Database::getConnection();
$stmt = $db->prepare(
    'INSERT INTO uploads (user_id, original_name, stored_name, file_size, extracted_text, page_count) VALUES (?, ?, ?, ?, ?, ?)'
);
$stmt->execute([
    $_SESSION['user_id'],
    basename($file['name']),
    $storedName,
    $file['size'],
    $extractedText,
    $pageCountGuess,
]);
$uploadId = (int) $db->lastInsertId();

logActivity($_SESSION['user_id'], 'pdf_upload', 'Uploaded ' . $file['name']);

jsonResponse([
    'success' => true,
    'upload_id' => $uploadId,
    'chars_extracted' => strlen($extractedText),
]);
