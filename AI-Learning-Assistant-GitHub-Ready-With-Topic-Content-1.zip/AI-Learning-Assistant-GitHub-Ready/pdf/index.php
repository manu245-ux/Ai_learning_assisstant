<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireLogin();
$db = Database::getConnection();
$userId = (int) $_SESSION['user_id'];

$stmt = $db->prepare('SELECT id, original_name, file_size, page_count, created_at FROM uploads WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([$userId]);
$uploads = $stmt->fetchAll();

$pageTitle = 'PDF Q&A';
include __DIR__ . '/../includes/header.php';
?>

<div class="card-panel">
  <h3><i class="fa-solid fa-file-pdf"></i> Upload a PDF</h3>
  <p class="text-muted">Upload lecture notes, readings, or textbook chapters (as PDF) and ask questions about them.</p>
  <form id="uploadForm" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
    <div class="input-group">
      <input type="file" name="pdf_file" id="pdfFileInput" class="form-control" accept="application/pdf" required>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-upload"></i> Upload</button>
    </div>
    <div class="form-text">Max <?= (int)MAX_UPLOAD_MB ?>MB. PDF files only.</div>
  </form>
  <div id="uploadStatus" class="mt-2"></div>
</div>

<div class="card-panel">
  <h3>Your PDFs</h3>
  <?php if (empty($uploads)): ?>
    <p class="text-muted">No PDFs uploaded yet.</p>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table align-middle">
        <thead><tr><th>File</th><th>Pages</th><th>Uploaded</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($uploads as $u): ?>
          <tr>
            <td><i class="fa-solid fa-file-pdf text-danger"></i> <?= e($u['original_name']) ?></td>
            <td><?= (int)$u['page_count'] ?: '—' ?></td>
            <td><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
            <td><a class="btn btn-sm btn-outline-primary" href="ask.php?upload_id=<?= (int)$u['id'] ?>">Ask Questions</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
<script>
document.getElementById('uploadForm').addEventListener('submit', async function(e){
  e.preventDefault();
  const status = document.getElementById('uploadStatus');
  status.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Uploading &amp; extracting text...';
  const formData = new FormData(this);
  try {
    const res = await fetch('upload.php', { method: 'POST', body: formData });
    const data = await res.json();
    if (data.success) {
      status.innerHTML = '<div class="alert alert-success py-2">Uploaded! Redirecting...</div>';
      window.location = 'ask.php?upload_id=' + data.upload_id;
    } else {
      status.innerHTML = '<div class="alert alert-danger py-2">' + data.error + '</div>';
    }
  } catch(err) {
    status.innerHTML = '<div class="alert alert-danger py-2">Upload failed. Please try again.</div>';
  }
});
</script>
