<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../api/gemini.php';
require_once __DIR__ . '/../api/api.php';
requireLogin();
$db = Database::getConnection();
$userId = (int) $_SESSION['user_id'];

$quiz = null;
$error = null;
$topic = '';
$difficulty = 'medium';
$count = 5;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $topic = trim($_POST['topic'] ?? '');
    $difficulty = in_array($_POST['difficulty'] ?? '', ['easy','medium','hard'], true) ? $_POST['difficulty'] : 'medium';
    $count = max(3, min(15, (int) ($_POST['count'] ?? 5)));

    if ($topic === '' || strlen($topic) > 200) {
        $error = 'Please enter a topic (up to 200 characters).';
    } else {
        [$system, $prompt] = getQuizGeneratorPrompt($topic, $difficulty, $count);
        try {
            $raw = Gemini::generate($prompt, [], $system);
            $clean = preg_replace('/^```json|```$/m', '', trim($raw));
            $parsed = json_decode(trim($clean), true);
            if (!is_array($parsed)) {
                $error = 'The AI response could not be parsed as a quiz. Please try again.';
            } else {
                $quiz = $parsed;
                $db->prepare('INSERT INTO quizzes (user_id, topic, quiz_json, difficulty) VALUES (?, ?, ?, ?)')
                   ->execute([$userId, $topic, json_encode($quiz), $difficulty]);
                logActivity($userId, 'quiz_generated', 'Generated quiz on ' . $topic);
            }
        } catch (GeminiException $e) {
            $error = $e->getMessage();
        }
    }
}

$pageTitle = 'Quiz Generator';
include __DIR__ . '/../includes/header.php';
?>

<div class="card-panel">
  <h3><i class="fa-solid fa-circle-question"></i> Quiz Generator</h3>
  <p class="text-muted">Enter a topic and get an instant multiple-choice quiz to test your knowledge.</p>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <form method="POST" class="row g-2">
    <?= csrfField() ?>
    <div class="col-md-6">
      <input type="text" name="topic" class="form-control" placeholder="e.g. Photosynthesis, WWII, Big-O Notation" value="<?= e($topic) ?>" required>
    </div>
    <div class="col-md-3">
      <select name="difficulty" class="form-select">
        <option value="easy" <?= $difficulty==='easy'?'selected':'' ?>>Easy</option>
        <option value="medium" <?= $difficulty==='medium'?'selected':'' ?>>Medium</option>
        <option value="hard" <?= $difficulty==='hard'?'selected':'' ?>>Hard</option>
      </select>
    </div>
    <div class="col-md-2">
      <input type="number" name="count" class="form-control" min="3" max="15" value="<?= (int)$count ?>">
    </div>
    <div class="col-md-1">
      <button class="btn btn-primary w-100" type="submit"><i class="fa-solid fa-bolt"></i></button>
    </div>
  </form>
</div>

<?php if ($quiz): ?>
<div class="card-panel">
  <h3>Your Quiz: <?= e($topic) ?></h3>
  <form id="quizForm">
    <?php foreach ($quiz as $i => $q): ?>
      <div class="quiz-question mb-3">
        <p class="fw-bold">Q<?= $i+1 ?>. <?= e($q['question']) ?></p>
        <?php foreach (($q['options'] ?? []) as $j => $opt): ?>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="q<?= $i ?>" id="q<?= $i ?>o<?= $j ?>" value="<?= e($opt) ?>">
            <label class="form-check-label" for="q<?= $i ?>o<?= $j ?>"><?= e($opt) ?></label>
          </div>
        <?php endforeach; ?>
        <div class="quiz-feedback mt-1" data-answer="<?= e($q['answer'] ?? '') ?>" data-explanation="<?= e($q['explanation'] ?? '') ?>" data-qname="q<?= $i ?>"></div>
      </div>
    <?php endforeach; ?>
    <button type="button" class="btn btn-success" onclick="gradeQuiz()">Check Answers</button>
  </form>
</div>
<script>
function gradeQuiz(){
  let correct = 0, total = 0;
  document.querySelectorAll('.quiz-feedback').forEach(fb => {
    total++;
    const qname = fb.dataset.qname;
    const selected = document.querySelector(`input[name="${qname}"]:checked`);
    const answer = fb.dataset.answer;
    if (selected && selected.value === answer) {
      correct++;
      fb.innerHTML = '<span class="text-success"><i class="fa-solid fa-check"></i> Correct! ' + fb.dataset.explanation + '</span>';
    } else {
      fb.innerHTML = '<span class="text-danger"><i class="fa-solid fa-xmark"></i> Correct answer: ' + answer + '. ' + fb.dataset.explanation + '</span>';
    }
  });
  Swal.fire('Score', `You got ${correct} / ${total} correct!`, correct === total ? 'success' : 'info');
}
</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
