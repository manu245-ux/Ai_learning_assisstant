<?php
/** chat/new_chat.php - creates a new empty chat session, returns its id */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');
if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success' => false, 'error' => 'Invalid method.'], 405);
requireCsrf();

$db = Database::getConnection();
$stmt = $db->prepare('INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)');
$stmt->execute([$_SESSION['user_id'], 'New Chat']);
$id = (int) $db->lastInsertId();

jsonResponse(['success' => true, 'chat_session_id' => $id, 'title' => 'New Chat']);
