<?php
/** chat/search.php?q=term - full-text-ish search across the user's chats */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');
if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);

$q = trim($_GET['q'] ?? '');
if ($q === '') jsonResponse(['success' => true, 'results' => []]);

$db = Database::getConnection();
$stmt = $db->prepare(
    'SELECT DISTINCT cs.id, cs.title, cs.updated_at
     FROM chat_sessions cs
     JOIN messages m ON m.chat_session_id = cs.id
     WHERE cs.user_id = ? AND (m.content LIKE ? OR cs.title LIKE ?)
     ORDER BY cs.updated_at DESC LIMIT 30'
);
$like = '%' . $q . '%';
$stmt->execute([$_SESSION['user_id'], $like, $like]);
jsonResponse(['success' => true, 'results' => $stmt->fetchAll()]);
