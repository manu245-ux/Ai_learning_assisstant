<?php
/**
 * chat/export.php?chat_session_id=N&format=txt|pdf
 * Exports a conversation. PDF export uses a minimal built-in PDF writer
 * (no external library required) — good enough for plain text transcripts.
 */
require_once __DIR__ . '/../includes/bootstrap.php';
if (!isLoggedIn()) { http_response_code(401); die('Not authenticated.'); }

$id     = (int) ($_GET['chat_session_id'] ?? 0);
$format = $_GET['format'] ?? 'txt';

$db = Database::getConnection();
$stmt = $db->prepare('SELECT title FROM chat_sessions WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $_SESSION['user_id']]);
$session = $stmt->fetch();
if (!$session) { http_response_code(404); die('Chat not found.'); }

$stmt = $db->prepare('SELECT role, content, created_at FROM messages WHERE chat_session_id = ? ORDER BY id ASC');
$stmt->execute([$id]);
$messages = $stmt->fetchAll();

$safeTitle = preg_replace('/[^A-Za-z0-9_\- ]/', '', $session['title']) ?: 'chat_export';

// Build plain-text transcript (shared by both formats)
$lines = [];
$lines[] = strtoupper($session['title']);
$lines[] = str_repeat('=', 60);
foreach ($messages as $m) {
    $who = $m['role'] === 'user' ? 'YOU' : 'AI ASSISTANT';
    $lines[] = "[{$m['created_at']}] {$who}:";
    $lines[] = $m['content'];
    $lines[] = str_repeat('-', 60);
}
$transcript = implode("\n", $lines);

if ($format === 'txt') {
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $safeTitle . '.txt"');
    echo $transcript;
    exit;
}

if ($format === 'pdf') {
    // Minimal single-content-stream PDF generator (pure PHP, no dependencies).
    // Good for plain-text transcripts. Wraps long lines to fit page width.
    function pdfEscape(string $s): string {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }
    function wrapLine(string $line, int $maxChars = 95): array {
        if ($line === '') return [''];
        return str_split($line, $maxChars) ?: [''];
    }

    $wrapped = [];
    foreach (explode("\n", $transcript) as $line) {
        foreach (wrapLine($line) as $chunk) $wrapped[] = $chunk;
    }

    $linesPerPage = 55;
    $pages = array_chunk($wrapped, $linesPerPage);

    $objects = [];
    $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    $kids = [];
    $objNum = 4; // 3 is font, pages start at 4
    $objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>";

    $pageObjNums = [];
    $contentObjNums = [];
    foreach ($pages as $i => $pageLines) {
        $pageObjNums[] = $objNum;
        $objNum++;
    }
    foreach ($pages as $i => $pageLines) {
        $contentObjNums[] = $objNum;
        $objNum++;
    }

    foreach ($pages as $i => $pageLines) {
        $y = 780;
        $content = "BT /F1 10 Tf 40 {$y} Td 12 TL\n";
        foreach ($pageLines as $line) {
            $content .= "(" . pdfEscape($line) . ") Tj T*\n";
        }
        $content .= "ET";
        $contentObjNums[$i]; // noop
        $objects[$contentObjNums[$i]] = "<< /Length " . strlen($content) . " >>\nstream\n{$content}\nendstream";
        $objects[$pageObjNums[$i]] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            . "/Resources << /Font << /F1 3 0 R >> >> /Contents {$contentObjNums[$i]} 0 R >>";
    }

    $kidsRefs = implode(' ', array_map(fn($n) => "{$n} 0 R", $pageObjNums));
    $objects[2] = "<< /Type /Pages /Kids [{$kidsRefs}] /Count " . count($pageObjNums) . " >>";

    ksort($objects);
    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $num => $body) {
        $offsets[$num] = strlen($pdf);
        $pdf .= "{$num} 0 obj\n{$body}\nendobj\n";
    }
    $xrefStart = strlen($pdf);
    $count = max(array_keys($objects)) + 1;
    $pdf .= "xref\n0 {$count}\n0000000000 65535 f \n";
    for ($n = 1; $n < $count; $n++) {
        $off = $offsets[$n] ?? 0;
        $pdf .= sprintf("%010d 00000 n \n", $off);
    }
    $pdf .= "trailer\n<< /Size {$count} /Root 1 0 R >>\nstartxref\n{$xrefStart}\n%%EOF";

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $safeTitle . '.pdf"');
    header('Content-Length: ' . strlen($pdf));
    echo $pdf;
    exit;
}

http_response_code(400);
echo 'Invalid format. Use ?format=txt or ?format=pdf';
