<?php
/** chat/delete.php - deletes a chat session and its messages (cascade) */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');
if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success' => false, 'error' => 'Invalid method.'], 405);
requireCsrf();

$id = (int) ($_POST['chat_session_id'] ?? 0);
$db = Database::getConnection();
$stmt = $db->prepare('DELETE FROM chat_sessions WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $_SESSION['user_id']]);

jsonResponse(['success' => $stmt->rowCount() > 0]);
