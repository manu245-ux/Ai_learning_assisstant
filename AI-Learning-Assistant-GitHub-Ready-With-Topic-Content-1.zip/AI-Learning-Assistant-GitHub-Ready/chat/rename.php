<?php
/** chat/rename.php - renames a chat session (must belong to current user) */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');
if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success' => false, 'error' => 'Invalid method.'], 405);
requireCsrf();

$id    = (int) ($_POST['chat_session_id'] ?? 0);
$title = trim($_POST['title'] ?? '');
if ($title === '' || mb_strlen($title) > 150) {
    jsonResponse(['success' => false, 'error' => 'Title must be 1-150 characters.'], 422);
}

$db = Database::getConnection();
$stmt = $db->prepare('UPDATE chat_sessions SET title = ? WHERE id = ? AND user_id = ?');
$stmt->execute([$title, $id, $_SESSION['user_id']]);

jsonResponse(['success' => $stmt->rowCount() > 0]);
