<?php
/** chat/get_messages.php?chat_session_id=N - returns message history as JSON */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');
if (!isLoggedIn()) jsonResponse(['success' => false, 'error' => 'Not authenticated.'], 401);

$id = (int) ($_GET['chat_session_id'] ?? 0);
$db = Database::getConnection();

$stmt = $db->prepare('SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $_SESSION['user_id']]);
if (!$stmt->fetch()) jsonResponse(['success' => false, 'error' => 'Chat not found.'], 404);

$stmt = $db->prepare('SELECT role, content, tool, created_at FROM messages WHERE chat_session_id = ? ORDER BY id ASC');
$stmt->execute([$id]);
jsonResponse(['success' => true, 'messages' => $stmt->fetchAll()]);
