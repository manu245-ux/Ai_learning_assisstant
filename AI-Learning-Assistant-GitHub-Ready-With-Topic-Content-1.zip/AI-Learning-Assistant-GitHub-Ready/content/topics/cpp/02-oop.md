# C++ Object-Oriented Programming

## Four pillars
1. Encapsulation — bundle data and methods and control access.
2. Abstraction — expose essential behavior and hide implementation details.
3. Inheritance — derive new classes from existing classes.
4. Polymorphism — allow one interface to represent different implementations.

## Important C++ topics
Constructors, destructors, copy constructors, static members, friend functions, operator overloading, virtual functions and multiple inheritance.

## Exam distinction
Function/operator overloading is compile-time polymorphism. Virtual-function overriding enables runtime polymorphism.
