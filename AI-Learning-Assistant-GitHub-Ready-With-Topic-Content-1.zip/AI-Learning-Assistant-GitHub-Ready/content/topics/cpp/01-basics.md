# C++ Basics

## Overview
C++ is a compiled, general-purpose programming language used for systems, applications, competitive programming and performance-sensitive software.

## Core topics
- Variables and constants
- Data types: `int`, `float`, `double`, `char`, `bool`, `string`
- Operators
- Input/output with `cin` and `cout`
- Conditions: `if`, `else`, `switch`
- Loops: `for`, `while`, `do-while`
- Functions and scope

## Example
```cpp
#include <iostream>
using namespace std;
int main() { int n; cin >> n; cout << n*n; }
```

## Key point
Compilation converts source code into an executable program. Learn syntax, control flow and functions before moving to OOP and STL.
