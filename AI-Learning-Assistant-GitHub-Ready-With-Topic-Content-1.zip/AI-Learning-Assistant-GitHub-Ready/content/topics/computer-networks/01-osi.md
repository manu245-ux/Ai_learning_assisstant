# Computer Networks and OSI Model

A network connects devices so they can exchange data and share resources.

## OSI layers
1. Physical
2. Data Link
3. Network
4. Transport
5. Session
6. Presentation
7. Application

## Core terms
Bandwidth, latency, throughput, packet, protocol, IP address, MAC address and port.
