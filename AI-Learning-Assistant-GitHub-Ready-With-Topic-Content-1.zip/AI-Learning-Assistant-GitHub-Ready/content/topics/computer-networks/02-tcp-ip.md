# TCP, UDP and IP

## TCP
Connection-oriented and reliable. Provides sequencing, retransmission, flow control and congestion control.

## UDP
Connectionless and lightweight. Useful when low overhead and application-level control are important.

## IP
Provides logical addressing and routing between networks.

## Ports
Ports identify application-level endpoints on a host.
