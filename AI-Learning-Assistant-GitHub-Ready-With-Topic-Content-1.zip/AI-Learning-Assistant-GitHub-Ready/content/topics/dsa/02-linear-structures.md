# Arrays, Linked Lists, Stacks and Queues

## Array
Stores same-type elements in contiguous memory. Indexed access is typically `O(1)`.

## Linked list
A sequence of nodes connected by links. Insertion can be `O(1)` when the required node/position is already known.

## Stack
LIFO: last in, first out. Main operations: push, pop, top.

## Queue
FIFO: first in, first out. Main operations: enqueue, dequeue, front.

## Applications
Stacks: recursion, undo, expression evaluation. Queues: scheduling, buffering, BFS.
