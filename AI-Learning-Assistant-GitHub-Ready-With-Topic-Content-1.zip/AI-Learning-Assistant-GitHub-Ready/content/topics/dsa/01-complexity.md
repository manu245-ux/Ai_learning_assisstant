# Complexity Analysis

Time complexity describes how running time grows with input size. Space complexity describes additional memory usage.

## Common orders
`O(1)`, `O(log n)`, `O(n)`, `O(n log n)`, `O(n²)`, `O(2^n)`.

## Rules
Ignore constant factors and lower-order terms for asymptotic analysis.

## Examples
Array indexing is typically `O(1)`. Linear search is `O(n)`. Binary search on sorted data is `O(log n)`.
