# Trees and Graphs

A tree is a connected acyclic graph. A graph contains vertices and edges and may be directed/undirected or weighted/unweighted.

## Traversals
- Trees: preorder, inorder, postorder, level order.
- Graphs: BFS and DFS.

## Important algorithms
Binary-search-tree operations, heap operations, Dijkstra for non-negative weighted shortest paths and topological sorting for directed acyclic graphs.
