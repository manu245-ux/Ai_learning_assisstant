# Backend, APIs and Web Security

A backend handles business logic, authentication, authorization, database access and APIs.

## Typical flow
Client → HTTP request → route/controller → business logic → database → response.

## Security basics
Validate input, use prepared SQL statements, protect sessions, enforce authorization, hash passwords securely and never expose API keys in client-side code.
