# HTML, CSS and JavaScript

HTML defines structure, CSS controls presentation, and JavaScript adds behavior and interactivity.

## HTML
Use semantic elements such as `header`, `nav`, `main`, `section`, `article` and `footer`.

## CSS
Learn the box model, selectors, flexbox, grid, responsive design and accessibility.

## JavaScript
Learn variables, functions, arrays/objects, DOM manipulation, events, promises and `fetch`.
