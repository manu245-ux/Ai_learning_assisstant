# AI and Machine Learning Fundamentals

Artificial intelligence concerns systems that perform tasks associated with intelligent behavior. Machine learning learns patterns from data.

## Learning types
- Supervised: labeled examples.
- Unsupervised: discover structure without target labels.
- Reinforcement: learn using rewards and penalties.

## ML workflow
Problem definition → data collection → preprocessing → train/validation/test split → training → evaluation → deployment → monitoring.
