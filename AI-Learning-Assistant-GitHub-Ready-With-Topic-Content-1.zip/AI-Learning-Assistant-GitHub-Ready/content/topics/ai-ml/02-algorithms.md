# Common Machine Learning Algorithms

Linear regression predicts continuous values. Logistic regression is commonly used for classification. Decision trees learn feature-based rules. K-nearest neighbors uses nearby examples. K-means groups observations into clusters.

## Evaluation
Classification: accuracy, precision, recall, F1-score. Regression: MAE, MSE, RMSE.

## Overfitting
A model overfits when it learns training-specific patterns and generalizes poorly. Validation, regularization and appropriate model complexity can help.
