# Operating System Fundamentals

An operating system manages hardware resources and provides services to applications.

## Responsibilities
Process management, memory management, file systems, I/O management, protection and security.

## Kernel
The privileged core of an OS that manages system resources and provides low-level services.
