# Processes and Threads

A process is a program in execution with its own resources/address space. A thread is an execution unit within a process.

## Process states
New, ready, running, waiting/blocked and terminated.

## Context switch
The OS saves one execution context and restores another, allowing multiple processes/threads to share CPU time.
