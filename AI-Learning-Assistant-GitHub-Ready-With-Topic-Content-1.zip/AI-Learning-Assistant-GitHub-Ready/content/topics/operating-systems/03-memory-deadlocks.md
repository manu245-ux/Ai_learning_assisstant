# Memory Management and Deadlocks

## Memory
Important concepts include paging, segmentation, virtual memory and page replacement.

## Deadlock
A set of processes can become permanently blocked waiting for resources.

## Four Coffman conditions
Mutual exclusion, hold-and-wait, no preemption and circular wait.

Deadlock prevention breaks at least one necessary condition; avoidance uses resource-allocation knowledge, such as the Banker’s algorithm.
