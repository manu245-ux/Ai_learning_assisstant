# SDLC Models

## Waterfall
Sequential model; suitable when requirements are stable.

## Prototype
Build an early model to clarify uncertain requirements.

## Incremental
Deliver the system in multiple usable increments.

## Spiral
Iterative development with explicit risk analysis.

## RAD
Emphasizes rapid development, prototyping and reuse.

## Agile
Iterative and incremental delivery with frequent feedback and adaptation.
