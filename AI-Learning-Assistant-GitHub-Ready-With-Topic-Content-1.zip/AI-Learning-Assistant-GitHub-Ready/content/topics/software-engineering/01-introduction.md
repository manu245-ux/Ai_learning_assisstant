# Software Engineering and SDLC

Software engineering applies systematic engineering principles to software development and maintenance.

## SDLC stages
Requirements → design → implementation → testing → deployment → maintenance.

## Goals
Meet functional requirements while managing quality, cost, schedule, security, reliability and maintainability.
