# Requirement Engineering

Activities include elicitation, analysis, specification, validation and management.

## Functional requirements
Describe what the system must do.

## Non-functional requirements
Describe quality attributes or constraints such as performance, security, usability, reliability and scalability.

## Good requirements
Clear, consistent, feasible, testable, traceable and unambiguous.
