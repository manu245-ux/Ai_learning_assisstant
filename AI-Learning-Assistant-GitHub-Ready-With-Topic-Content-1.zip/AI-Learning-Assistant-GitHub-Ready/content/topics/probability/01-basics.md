# Probability Basics

Probability measures uncertainty on a scale from 0 to 1.

For equally likely outcomes: `P(A) = favorable outcomes / total outcomes`.

## Complement
`P(Aᶜ) = 1 - P(A)`.

## Union
`P(A ∪ B) = P(A) + P(B) - P(A ∩ B)`.
