# Conditional Probability and Independence

Conditional probability is `P(A|B) = P(A ∩ B) / P(B)` when `P(B) > 0`.

Events A and B are independent when `P(A ∩ B) = P(A)P(B)`.

Independence means learning that one event occurred does not change the probability of the other.
