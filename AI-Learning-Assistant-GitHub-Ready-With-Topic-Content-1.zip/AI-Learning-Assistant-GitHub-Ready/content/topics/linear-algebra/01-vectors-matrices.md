# Vectors and Matrices

A vector can represent a direction/magnitude or an ordered collection of numbers. A matrix is a rectangular array.

## Operations
Vector addition and scalar multiplication are component-wise. Matrix multiplication combines rows and columns and is generally not commutative.

## Applications
Linear algebra is foundational in machine learning, data science, graphics, optimization and scientific computing.
