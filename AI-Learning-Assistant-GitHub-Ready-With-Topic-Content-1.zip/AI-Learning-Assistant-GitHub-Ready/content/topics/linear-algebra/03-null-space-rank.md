# Vector Spaces, Null Space and Rank

A vector space is closed under vector addition and scalar multiplication.

## Null space
The null space of `A` is the set of all `x` satisfying `Ax = 0`.

## Rank
Rank is the dimension of the column space and equals the dimension of the row space. It indicates how many independent directions a matrix contains.
