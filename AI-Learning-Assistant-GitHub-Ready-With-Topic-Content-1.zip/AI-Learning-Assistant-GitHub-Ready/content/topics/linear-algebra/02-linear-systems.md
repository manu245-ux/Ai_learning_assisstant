# Systems of Linear Equations

A system can be represented as `Ax = b`.

## Column picture
The columns of `A` are vectors whose linear combination produces `b`.

## Gaussian elimination
Elimination transforms a system while preserving its solution set.

## Independence
Columns are linearly independent if no non-trivial linear combination gives the zero vector.
