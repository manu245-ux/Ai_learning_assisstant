# Normalization and Transactions

## Normal forms
- 1NF: atomic values.
- 2NF: 1NF plus no partial dependency on a composite key.
- 3NF: 2NF plus no transitive dependency of non-key attributes on a key.

Normalization reduces redundancy and insertion, deletion and update anomalies.

## Transactions
ACID = Atomicity, Consistency, Isolation, Durability.

## Concurrency anomalies
Lost update, dirty read and non-repeatable read are common problems. Serializability helps determine whether a concurrent schedule is equivalent to a serial schedule.
