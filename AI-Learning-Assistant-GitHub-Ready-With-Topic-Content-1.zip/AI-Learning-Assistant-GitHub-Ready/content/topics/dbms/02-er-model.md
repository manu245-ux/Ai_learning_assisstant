# ER Model

The Entity-Relationship model describes entities, attributes and relationships before database implementation.

## Concepts
- Entity: distinguishable real-world object.
- Attribute: property of an entity.
- Relationship: association between entities.
- Cardinality: 1:1, 1:N, N:1 or M:N.

## Mapping
Strong entities normally become tables. Many-to-many relationships commonly become separate junction tables.
