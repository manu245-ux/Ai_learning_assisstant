# DBMS Fundamentals

A Database Management System stores, retrieves and manages data while providing controlled access.

## Why DBMS?
Concurrency control, integrity constraints, security, recovery, transactions and efficient query processing.

## Relational model
Data is represented by relations (tables), tuples (rows) and attributes (columns).

## Keys
A primary key uniquely identifies a row. A foreign key references a key in another relation.
