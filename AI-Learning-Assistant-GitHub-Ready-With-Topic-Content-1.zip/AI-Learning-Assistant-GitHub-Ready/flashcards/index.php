<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../api/gemini.php';
require_once __DIR__ . '/../api/api.php';
requireLogin();
$db = Database::getConnection();
$userId = (int) $_SESSION['user_id'];

$cards = null;
$error = null;
$topic = '';
$count = 10;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $topic = trim($_POST['topic'] ?? '');
    $count = max(4, min(20, (int) ($_POST['count'] ?? 10)));

    if ($topic === '' || strlen($topic) > 200) {
        $error = 'Please enter a topic (up to 200 characters).';
    } else {
        [$system, $prompt] = getFlashcardGeneratorPrompt($topic, $count);
        try {
            $raw = Gemini::generate($prompt, [], $system);
            $clean = preg_replace('/^```json|```$/m', '', trim($raw));
            $parsed = json_decode(trim($clean), true);
            if (!is_array($parsed)) {
                $error = 'The AI response could not be parsed as flashcards. Please try again.';
            } else {
                $cards = $parsed;
                $db->prepare('INSERT INTO flashcards (user_id, deck_title, cards_json) VALUES (?, ?, ?)')
                   ->execute([$userId, $topic, json_encode($cards)]);
                logActivity($userId, 'flashcards_generated', 'Generated flashcards on ' . $topic);
            }
        } catch (GeminiException $e) {
            $error = $e->getMessage();
        }
    }
}

$stmt = $db->prepare('SELECT id, deck_title, cards_json, created_at FROM flashcards WHERE user_id = ? ORDER BY created_at DESC LIMIT 10');
$stmt->execute([$userId]);
$decks = $stmt->fetchAll();

$pageTitle = 'Flashcards';
include __DIR__ . '/../includes/header.php';
?>

<div class="card-panel">
  <h3><i class="fa-solid fa-clone"></i> Flashcard Generator</h3>
  <p class="text-muted">Generate a deck of flashcards on any topic for quick, active-recall study sessions.</p>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

  <form method="POST" class="row g-2">
    <?= csrfField() ?>
    <div class="col-md-8">
      <input type="text" name="topic" class="form-control" placeholder="e.g. Spanish verb conjugations, Cell biology" value="<?= e($topic) ?>" required>
    </div>
    <div class="col-md-2">
      <input type="number" name="count" class="form-control" min="4" max="20" value="<?= (int)$count ?>">
    </div>
    <div class="col-md-2">
      <button class="btn btn-primary w-100" type="submit"><i class="fa-solid fa-bolt"></i> Generate</button>
    </div>
  </form>
</div>

<?php if ($cards): ?>
<div class="card-panel">
  <h3>Deck: <?= e($topic) ?></h3>
  <div class="flashcard-grid">
    <?php foreach ($cards as $i => $c): ?>
      <div class="flashcard" onclick="this.classList.toggle('flipped')">
        <div class="flashcard-inner">
          <div class="flashcard-front"><?= e($c['front'] ?? '') ?></div>
          <div class="flashcard-back"><?= e($c['back'] ?? '') ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <p class="text-muted mt-2 small">Click a card to flip it.</p>
</div>
<?php endif; ?>

<div class="card-panel">
  <h3>Your Decks</h3>
  <?php if (empty($decks)): ?>
    <p class="text-muted">No flashcard decks yet.</p>
  <?php else: ?>
    <ul class="recent-chat-list">
      <?php foreach ($decks as $d): ?>
        <li><?= e($d['deck_title']) ?> <span class="text-muted small"><?= e(date('M j', strtotime($d['created_at']))) ?></span></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
