# Security Policy

## Supported versions

The latest version on the default branch is the primary supported version.

## Reporting a vulnerability

Please do not publish sensitive vulnerabilities, credentials, API keys, or
private user data in a public issue.

Instead, contact the project maintainer privately and include:
- a short description of the issue,
- steps to reproduce,
- affected files/endpoints,
- potential impact.

## Important deployment rules

- Never commit `.env` or real API keys.
- Use platform environment variables for production secrets.
- Use HTTPS in production.
- Keep uploaded files non-executable.
- Do not paste database passwords or API keys into screenshots/issues.
