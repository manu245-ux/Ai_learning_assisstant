-- ============================================================
-- AI Learning Assistant - Database Schema
-- Import this file via phpMyAdmin or:
--   mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS ai_learning_assistant
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE ai_learning_assistant;

-- ------------------------------------------------------------
-- USERS
-- ------------------------------------------------------------
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student','admin') NOT NULL DEFAULT 'student',
    avatar VARCHAR(255) DEFAULT NULL,
    theme ENUM('light','dark') NOT NULL DEFAULT 'light',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SESSIONS (custom "remember me" / active session tracking)
-- ------------------------------------------------------------
CREATE TABLE sessions (
    id VARCHAR(64) PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent VARCHAR(255) DEFAULT NULL,
    last_activity DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sessions_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CHAT SESSIONS (conversations)
-- ------------------------------------------------------------
CREATE TABLE chat_sessions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    title VARCHAR(150) NOT NULL DEFAULT 'New Chat',
    pdf_upload_id INT UNSIGNED DEFAULT NULL,
    is_pinned TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_chat_sessions_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- MESSAGES
-- ------------------------------------------------------------
CREATE TABLE messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    chat_session_id INT UNSIGNED NOT NULL,
    role ENUM('user','assistant') NOT NULL,
    content MEDIUMTEXT NOT NULL,
    tool VARCHAR(50) DEFAULT 'chat', -- chat, notes, quiz, flashcards, code, math, assignment
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chat_session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
    INDEX idx_messages_session (chat_session_id),
    FULLTEXT INDEX ft_messages_content (content)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- UPLOADS (PDF files)
-- ------------------------------------------------------------
CREATE TABLE uploads (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    file_size INT UNSIGNED NOT NULL,
    extracted_text MEDIUMTEXT,
    page_count INT UNSIGNED DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_uploads_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- NOTES (summarizer results)
-- ------------------------------------------------------------
CREATE TABLE notes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    title VARCHAR(150) NOT NULL,
    source_text MEDIUMTEXT,
    summary MEDIUMTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notes_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- QUIZZES
-- ------------------------------------------------------------
CREATE TABLE quizzes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    topic VARCHAR(200) NOT NULL,
    quiz_json MEDIUMTEXT NOT NULL, -- JSON array of {question, options, answer, explanation}
    difficulty ENUM('easy','medium','hard') NOT NULL DEFAULT 'medium',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_quizzes_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- FLASHCARDS
-- ------------------------------------------------------------
CREATE TABLE flashcards (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    deck_title VARCHAR(150) NOT NULL,
    cards_json MEDIUMTEXT NOT NULL, -- JSON array of {front, back}
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_flashcards_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- ACTIVITY LOGS (admin panel)
-- ------------------------------------------------------------
CREATE TABLE activity_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_logs_user (user_id),
    INDEX idx_logs_action (action)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SETTINGS (per-user key/value app settings)
-- ------------------------------------------------------------
CREATE TABLE settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    setting_key VARCHAR(100) NOT NULL,
    setting_value VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_setting (user_id, setting_key)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SAMPLE DATA
-- ------------------------------------------------------------
-- Default admin account: email admin@example.com / password: Admin@123
-- (hash below corresponds to "Admin@123" using PHP password_hash/BCRYPT)
INSERT INTO users (full_name, email, password_hash, role) VALUES
('System Admin', 'admin@example.com', '$2y$10$Q0Y2p1z2b1qk3ZL8y0m8xO1s6Y8yQe9d6nQe4v3zJb1H2a1a1a1a1', 'admin');

-- NOTE: The hash above is a placeholder format example. On first run, use
-- register.php to create real accounts (recommended), OR run:
--   php -r "echo password_hash('Admin@123', PASSWORD_BCRYPT);"
-- and UPDATE users SET password_hash='<result>' WHERE email='admin@example.com';

INSERT INTO chat_sessions (user_id, title) VALUES
(1, 'Welcome Chat');

INSERT INTO messages (chat_session_id, role, content, tool) VALUES
(1, 'assistant', 'Hi! I am your AI Learning Assistant. Ask me anything about your coursework, upload a PDF, or try the study tools in the sidebar.', 'chat');
