<?php
/**
 * config/env.php
 * Minimal .env file loader (no Composer dependency).
 * Reads KEY=VALUE lines from .env and injects them into getenv()/$_ENV
 * ONLY if that key isn't already set by the real environment (platform
 * env vars set in Railway/Render/cPanel always take priority over .env).
 */

function loadEnv(string $path): void
{
    if (!file_exists($path)) {
        return; // no .env file — rely entirely on real platform environment variables
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        if (!str_contains($line, '=')) continue;

        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        // Strip surrounding quotes if present
        $value = trim($value, "\"'");

        // Don't override real environment variables already set by the host platform
        if (getenv($key) === false) {
            putenv("{$key}={$value}");
            $_ENV[$key] = $value;
        }
    }
}

/** Get an env var with a default fallback. */
function env(string $key, $default = null)
{
    $value = getenv($key);
    if ($value === false) return $default;
    // Normalize common boolean-ish strings
    if (in_array(strtolower($value), ['true', 'false'], true)) {
        return strtolower($value) === 'true';
    }
    return $value;
}
