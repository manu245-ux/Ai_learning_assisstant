<?php
/**
 * config/config.php
 * ------------------------------------------------------------
 * Central configuration file.
 *
 * CHANGED FOR DEPLOYMENT: all secrets/environment-specific values now come
 * from environment variables (via config/env.php's loadEnv()+env() helpers)
 * instead of being hardcoded. Locally, copy .env.example to .env and fill
 * it in. On Railway/Render/cPanel, set these as real platform environment
 * variables instead of using a .env file -- .env is a local-dev convenience
 * only and should never be committed to version control.
 * ------------------------------------------------------------
 */

require_once __DIR__ . '/env.php';
loadEnv(__DIR__ . '/../.env');

// ---- Environment ----
$appEnv = env('APP_ENV', 'local');
error_reporting(E_ALL);
ini_set('display_errors', $appEnv === 'local' ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../logs_php_errors.log');
define('APP_ENV', $appEnv);

// ---- Database ----
// NOTE: Railway/Render MySQL add-ons typically expose a single MYSQL_URL /
// DATABASE_URL connection string rather than separate host/user/pass vars.
// We support both styles below.
if (env('DATABASE_URL')) {
    $dbUrl = parse_url(env('DATABASE_URL'));
    define('DB_HOST', $dbUrl['host']);
    define('DB_PORT', $dbUrl['port'] ?? 3306);
    define('DB_NAME', ltrim($dbUrl['path'] ?? '', '/'));
    define('DB_USER', $dbUrl['user'] ?? 'root');
    define('DB_PASS', $dbUrl['pass'] ?? '');
} else {
    define('DB_HOST', env('DB_HOST', 'localhost'));
    define('DB_PORT', env('DB_PORT', 3306));
    define('DB_NAME', env('DB_NAME', 'ai_learning_assistant'));
    define('DB_USER', env('DB_USER', 'root'));
    define('DB_PASS', env('DB_PASS', ''));
}
define('DB_CHARSET', 'utf8mb4');

// ---- Google Gemini API ----
// Get a free key at https://aistudio.google.com/app/apikey
define('GEMINI_API_KEY', env('GEMINI_API_KEY', ''));
define('GEMINI_MODEL', env('GEMINI_MODEL', 'gemini-2.0-flash'));
define('GEMINI_ENDPOINT', 'https://generativelanguage.googleapis.com/v1beta/models/' . GEMINI_MODEL . ':generateContent');
define('GEMINI_TIMEOUT_SECONDS', 30);

// ---- App ----
define('APP_NAME', 'AI Learning Assistant');
define('APP_URL', rtrim(env('APP_URL', 'http://localhost/AI-Learning-Assistant'), '/'));
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_MB', 15);
define('ALLOWED_UPLOAD_EXT', ['pdf']);
define('MAX_PDF_CHARS_FOR_PROMPT', 18000); // guardrail so we don't blow the Gemini context/cost

// ---- Session security ----
define('SESSION_NAME', 'ala_session');
ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');
if ($appEnv !== 'local') {
    // Force secure cookies in production (assumes HTTPS, which Railway/Render/most hosts provide by default)
    ini_set('session.cookie_secure', '1');
    ini_set('session.cookie_samesite', 'Lax');
}

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

date_default_timezone_set('UTC');
