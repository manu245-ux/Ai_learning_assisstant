---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
assignees: ""
---

## Describe the bug

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Actual behavior

## Environment
- PHP version:
- MySQL version:
- Browser:
- Deployment platform:

## Logs / screenshots

> Remove secrets, API keys, passwords, and personal data before posting.
